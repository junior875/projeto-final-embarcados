#include "config.h" 
#include "lcd.h"
#include "adc.h"
#include "rgb.h"
#include "keypad.h"
#include "bits.h"
#include "pwm.h"
#include "atraso.h"
#include "ds1307.h"
#include "i2c.h"
#include "ssd.h"
#include "io.h"
#include "so.h"

void tempo() {
    int cont;
    if (kpReadKey() == 'A') {
        cont = cont + 1000;
    }
    if (kpReadKey() == 'Y') {
        cont = cont - 1000;
    }
    lcdCommand(0xC0); //second line
    lcdString("Hora: ");
    lcdChar((((cont / 360000) % 24) / 10) + 48);
    lcdChar((((cont / 360000) % 24) % 10) + 48);
    lcdChar(':');
    lcdChar((cont / 60000) % 6 + 48);
    lcdChar((cont / 6000) % 10 + 48);
    lcdChar(':');
    lcdChar((cont / 1000) % 6 + 48);
    lcdChar((cont / 100) % 10 + 48);
    lcdCommand(0x80); //first line
    kpDebounce();
}//end void tempo

void main(void) {
    static const char valor[] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71};
    static char display = 0;
    static char v0;
    int i, player = 0, cont, v = 0, aux, cont1 = 1, cont2 = 0;

    pinMode(DISP_4_PIN, OUTPUT);
    lcdInit();
    adcInit();
    kpInit();
    ssdInit();
    soInit();
    kpDebounce();
    while (kpReadKey() != 'S') {
        kpDebounce();
        //primeira linha
        lcdCommand(0x80);
        lcdString("----welcome----");
        //segunda linha
        lcdCommand(0xC0);
        lcdString("Funcoes: ");
        //atraso_ms(200);
    }//end while
    lcdCommand(0x01);
    for (;;) {
        kpDebounce();
        switch (player) {
            case 0:
                 kpDebounce();
                lcdCommand(0x80);
                lcdString("LAVAGENS");
                //segunda linha
                lcdCommand(0xC0);
                lcdString("ECO ENERGIA");
                if (kpReadKey() == 'R') {
                    lcdCommand(0x01);
                    cont1 = 0;
                    lcdCommand(0x01);
                    atraso_ms(100);
                }//end if
                while (cont1 == 0) {

                    kpDebounce();
                    lcdCommand(0x80);
                    lcdString("----QTD SABAO----");
                    lcdCommand(0xC0);
                    v = adcRead(0);
                    lcdChar(v % 10 + 48);
                    atraso_ms(100);
                    if (kpReadKey() == 'S') {
                        lcdCommand(0x01);
                        for(cont=0; cont<2000; cont++){
                            /*if (kpReadKey() != 0) {
                            cont = 2000;
                            break;
                            }//end if*/
                            lcdCommand(0x80);
                            lcdString("ECO ENERGIA:");
                            lcdChar(v % 10 + 48);
                            lcdString("QTD SABAO");
                            lcdCommand(0xC0);

                            lcdString("Hora: ");
                            lcdChar((((cont / 360000) % 24) / 10) + 48);
                            lcdChar((((cont / 360000) % 24) % 10) + 48);
                            lcdChar(':');
                            lcdChar((cont / 60000) % 6 + 48);
                            lcdChar((cont / 6000) % 10 + 48);
                            lcdChar(':');
                            lcdChar((cont / 1000) % 6 + 48);


                            lcdChar((cont / 100) % 10 + 48);
                            cont++;
                        }
                    }//end if
                    if (kpReadKey() == 'D') {
                        cont1 = 1;
                        lcdCommand(0x01);
                    }//end if
                }//end while
                if (kpReadKey() == 'L') {
                    lcdCommand(0x01);
                    player++;
                    atraso_ms(100);
                }//end if

                break;
            case 1:
                kpDebounce();
                lcdCommand(0x80);
                lcdString("LAVAGENS");
                //segunda linha
                lcdCommand(0xC0);
                lcdString("LOUCA SUJA");
                if (kpReadKey() == 'R') {
                    lcdCommand(0x01);
                    cont1 = 0;
                    lcdCommand(0x01);
                    atraso_ms(100);
                }//end if
                while (cont1 == 0) {
                    kpDebounce();
                    v = 7;
                        for(cont=0; cont<2000; cont++){
                            if (kpReadKey() != 0) {
                            cont = 2000;
                            break;
                            }//end if
                            lcdCommand(0x80);
                            lcdString("LOUCA SUJA:");
                            lcdChar(v % 10 + 48);
                            lcdString("QTD SABAO");
                            lcdCommand(0xC0);

                            lcdString("Hora: ");
                            lcdChar((((cont / 360000) % 24) / 10) + 48);
                            lcdChar((((cont / 360000) % 24) % 10) + 48);
                            lcdChar(':');
                            lcdChar((cont / 60000) % 6 + 48);
                            lcdChar((cont / 6000) % 10 + 48);
                            lcdChar(':');
                            lcdChar((cont / 1000) % 6 + 48);
                            lcdChar((cont / 100) % 10 + 48);
                            cont++;
                        }
                    if (kpReadKey() == 'D') {
                        cont1 = 1;
                        lcdCommand(0x01);
                    }//end if
                }//end while
                if (kpReadKey() == 'L') {
                    lcdCommand(0x01);
                    player++;
                    atraso_ms(100);
                }//end if

                break;
            case 2:
                kpDebounce();
                lcdCommand(0x80);
                lcdString("LAVAGENS");
                //segunda linha
                lcdCommand(0xC0);
                lcdString("LOUCA FRAGIL");
                if (kpReadKey() == 'R') {
                    lcdCommand(0x01);
                    cont1 = 0;
                    lcdCommand(0x01);
                    atraso_ms(100);
                }//end if
                while (cont1 == 0) {
                    kpDebounce();
                    v = 7;
                        for(cont=0; cont<2000; cont++){
                            if (kpReadKey() != 0) {
                            cont = 2000;
                            break;
                            }//end if
                            lcdCommand(0x80);
                            lcdString("BAIXA PRESSAO");
                            lcdCommand(0xC0);

                            lcdString("Hora: ");
                            lcdChar((((cont / 360000) % 24) / 10) + 48);
                            lcdChar((((cont / 360000) % 24) % 10) + 48);
                            lcdChar(':');
                            lcdChar((cont / 60000) % 6 + 48);
                            lcdChar((cont / 6000) % 10 + 48);
                            lcdChar(':');
                            lcdChar((cont / 1000) % 6 + 48);
                            lcdChar((cont / 100) % 10 + 48);
                            cont++;
                        }
                    if (kpReadKey() == 'D') {
                        cont1 = 1;
                        lcdCommand(0x01);
                    }//end if
                }//end while
                if (kpReadKey() == 'L') {
                    lcdCommand(0x01);
                    player++;
                    atraso_ms(100);
                }//end if

                break;
            case 3:
                 kpDebounce();
                lcdCommand(0x80);
                lcdString("LAVAGENS");
                //segunda linha
                lcdCommand(0xC0);
                lcdString("PANELAS");
                if (kpReadKey() == 'R') {
                    lcdCommand(0x01);
                    cont1 = 0;
                    lcdCommand(0x01);
                    atraso_ms(100);
                }//end if
                while (cont1 == 0) {
                    kpDebounce();
                    v = 7;
                        for(cont=0; cont<3000; cont++){
                            if (kpReadKey() != 0) {
                            cont = 2000;
                            break;
                            }//end if
                            lcdCommand(0x80);
                            lcdString("PANELAS:");
                            lcdString("10");
                            lcdString("QTD SABAO");
                            lcdCommand(0xC0);

                            lcdString("Hora: ");
                            lcdChar((((cont / 360000) % 24) / 10) + 48);
                            lcdChar((((cont / 360000) % 24) % 10) + 48);
                            lcdChar(':');
                            lcdChar((cont / 60000) % 6 + 48);
                            lcdChar((cont / 6000) % 10 + 48);
                            lcdChar(':');
                            lcdChar((cont / 1000) % 6 + 48);
                            lcdChar((cont / 100) % 10 + 48);
                            cont++;
                        }
                    if (kpReadKey() == 'D') {
                        cont1 = 1;
                        lcdCommand(0x01);
                    }//end if
                }//end while
                if (kpReadKey() == 'L') {
                    lcdCommand(0x01);
                    player++;
                    atraso_ms(100);
                }//end if

                break;        
            default:
                player = 0;
                break;
        }
        kpDebounce();
        //leitura do potenciometro
        v = adcRead(0);
        //inicializa apenas o quarto numero do display de 7 segmentos
        digitalWrite(DISP_4_PIN, LOW);
        soWrite(0x3F);
        //loop infinito do display
        switch (display) {
            case 0:
                soWrite(v);
                digitalWrite(DISP_4_PIN, HIGH);
                v++;
                atraso_ms(100);
                display = 0;
                break;
        }
    }
}
